from flask import Flask, render_template, request, redirect, url_for, session
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MongoDB setup
client = MongoClient("mongodb://localhost:27017/")
db = client['storybook_platform']

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user = {
            "username": request.form['username'],
            "password": generate_password_hash(request.form['password']),
            "role": "user"
        }
        db.users.insert_one(user)
        return redirect(url_for('home'))
    return render_template('register.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    user = db.users.find_one({"username": username})

    if user and check_password_hash(user['password'], password):
        session['username'] = username
        session['role'] = user['role']
        return redirect(url_for('admin_dashboard' if user['role'] == 'admin' else 'user_dashboard'))

    return "Login Failed. Please try again."

@app.route('/user/dashboard')
def user_dashboard():
    if 'username' in session and session['role'] == 'user':
        books = list(db.books.find())
        requests = db.book_requests.find({"username": session['username']})
        user_requests = {req["book_title"]: req for req in requests}
        return render_template('user_dashboard.html', books=books, user_requests=user_requests)
    return redirect(url_for('home'))


@app.route('/admin/dashboard')
def admin_dashboard():
    if 'username' in session and session['role'] == 'admin':
        users_count = db.users.count_documents({"role": "user"})
        requests = db.book_requests.find({"status": "pending"})
        return render_template('admin_dashboard.html', users_count=users_count, requests=requests)
    return redirect(url_for('home'))

@app.route('/request_book', methods=['POST'])
def request_book():
    if 'username' not in session:
        return redirect(url_for('home'))
    
    book_title = request.form['book_title']
    existing = db.book_requests.find_one({
        "username": session['username'],
        "book_title": book_title
    })
    if not existing:
        db.book_requests.insert_one({
            "username": session['username'],
            "book_title": book_title,
            "status": "pending"
        })
    return redirect(url_for('user_dashboard'))


@app.route('/approve_request/<username>/<book_title>')
def approve_request(username, book_title):
    if 'role' in session and session['role'] == 'admin':
        db.book_requests.update_one(
            {"username": username, "book_title": book_title},
            {"$set": {"status": "approved"}}
        )
    return redirect(url_for('admin_dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
