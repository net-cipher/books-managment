from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client['storybook_platform']

# Insert Book Details
books = [
    {
        "title": "Harry Potter story book",
        "filename": "harry_potter.pdf",  # Make sure this file is in static/books/
        "cover": "harry_potter.jpg",  # Make sure this file is in static/covers/
        "approved": False  # Set to False if you want admin to approve first
    }
]

# Insert books into MongoDB
db.books.insert_many(books)

print("Books inserted into MongoDB successfully!")
