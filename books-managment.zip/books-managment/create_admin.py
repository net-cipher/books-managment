from pymongo import MongoClient
from werkzeug.security import generate_password_hash

client = MongoClient("mongodb://localhost:27017/")
db = client['storybook_platform']

admin = {
    "username": "admin",
    "password": generate_password_hash("admin123"),
    "role": "admin"
}

db.users.insert_one(admin)
print("Admin account created!")
